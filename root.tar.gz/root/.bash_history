history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
ping 8.8.8.8
ip a
ip link set ens33 up
dhclient ens33
ip a
ping 8.8.8.8
poweroff
ping 8.8.8.8
ip a
ip link set ens33 up
dhclient ens33
ip a
ping 8.8.8.8
clear
apt-get update && apt-get upgrade -y
cat> /etc/apt/sources.list << EOF
deb http://deb.debian.org/debian bookworm main
deb http://deb.debian.org/debian bookworm-updates main
deb http://security.debian.org/debian-security bookworm-security main
EOF

clear
cat> /etc/apt/sources.list << EOF
deb http://deb.debian.org/debian bookworm main
deb http://deb.debian.org/debian bookworm-updates main
deb http://security.debian.org/debian-security bookworm-security main
EOF

clear
apt-get update && apt-get upgrade -y
clear
cat /etc/debian_version
clear
apt-get install openssh-server -y
clear
nano /etc/ssh/sshd_config
apt-get install nano -y
nano /etc/ssh/sshd_config
clear
clear
clear
systemctl restart ssh
systemctl status ssh
sshd -t
nano /etc/ssh/sshd_config
xlear
clear
systemctl restart ssh
systemctl status ssh
clear
mkdir -r /root/.ssh
mkdir -p /root/.ssh
clear
chmod 700 /root/.ssh
clear
nano /root/.shh/authorizaaed_keys
clear
apt-get install open-vm-tools -y
reboot
whoami
clear
ip a
ip link set ens33 up
dhclient ens33
ip a
chmod 600 /root/.ssh/authorized_keys
apt-get install apache2 php libapache2-mod-php -y
systemctl status apache2
clear
ls /var/www/html/
rm /var/www/html/index.html
cat /var/www/html/index.php
clear
apt-get install mariadb-server -y
clear
systemctl start mariadb
systemctl status mariadb
clear
mariadb
CLEAR
clear
mariadb ingenieria < /root/db.sql
mariadb ingenieria -e "SHOW TABLES;"
mariadb -e "DROP DATABASE ingenieria;"
mariadb ingenieria < /root/db.sql
mariadb < /root/db.sql
mariadb ingenieria -e "SHOW TABLES;"
mariadv
clear
mariadb
clear
systemctl restart apache2
php /var/www/html/index.php
apt-get install php-mysqli -y
systemctl restart apache2
php /var/www/html/index.php
clear
ipconfig
nano /etc/network/interfaces
clear
systemctl restart networking
systemctl status networking
ip link set ens33 down
ifup ens33
ip addr flush dev ens33
ip route flush dev ens33
ifup ens33
clear
ip a
reboot
ip a
poweroff
