#!/bin/bash

# Ayuda
if [ "$1" == "-help" ]; then
    echo "Uso: backup_full.sh <origen> <destino>"
    echo "Ejemplo: backup_full.sh /var/log /backup_dir"
    exit 0
fi

# Validar argumentos
if [ $# -ne 2 ]; then
    echo "Error: se requieren 2 argumentos. Use -help para más info."
    exit 1
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename $ORIGEN)

# Validar que origen existe
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el directorio origen '$ORIGEN' no existe o no está disponible."
    exit 1
fi

# Validar que destino existe
if [ ! -d "$DESTINO" ]; then
    echo "Error: el directorio destino '$DESTINO' no existe o no está disponible."
    exit 1
fi

# Ejecutar backup
tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"
echo "Backup realizado: $DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"